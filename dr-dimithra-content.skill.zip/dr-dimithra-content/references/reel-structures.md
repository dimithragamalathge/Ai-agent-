# Reel Slide Structures by Content Type

## Condition Explainer
1. Hook
2. "What is it?" — simple definition
3. Who gets it / how common
4. Main cause(s)
5. Key symptoms
6. Why it matters / what happens if untreated
7. What to do / when to see a doctor
8. Takeaway + CTA

## Myth Busting
1. Hook — state the myth
2. "Here's the truth"
3. The science (simple)
4. What you should actually do
5. Why this myth spreads
6. Takeaway + CTA

## Symptom Awareness
1. Hook — the symptom
2. Common (non-scary) causes
3. Warning signs to watch for
4. When to see a doctor
5. What NOT to do
6. Takeaway + CTA

## Treatment & Medication
1. Hook
2. What this drug/treatment does
3. Who it's for
4. How to use it correctly
5. Common side effects (reassuring tone)
6. Important warnings
7. Takeaway + CTA

## Preventive Health
1. Hook — the risk or habit
2. Why it matters
3. Step 1 (one slide)
4. Step 2 (one slide)
5. Step 3 (one slide)
6. What changes when you do this
7. Takeaway + CTA
